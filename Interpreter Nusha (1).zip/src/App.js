import LoginRegister from "./pages/LoginRegister";

export default function App() {
  const wrapper = {
    minHeight: "100vh",
    width: "100%",
    display: "grid",
    placeItems: "center"
  };

  return (
    <div style={wrapper}>
      <LoginRegister />
    </div>
  );
}