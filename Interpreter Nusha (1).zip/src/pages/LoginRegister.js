//Devin Randoll
import { useState } from "react";
import PageCard from "../components/PageCard";
import PageTitle from "../components/PageTitle";
import AppInput from "../components/AppInput";
import AppButton from "../components/AppButton";
import sharedStyles from "../styles/sharedStyles";

export default function LoginRegister() {
  const [isLogin, setIsLogin] = useState(true);
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: ""
  });

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  function handleSubmit() {
    if (isLogin) {
      alert("Logged in as " + form.email);
    } else {
      alert("Account created for " + form.name);
    }
  }

  return (
    <PageCard>
      <PageTitle>FitCircle</PageTitle>

      {!isLogin && (
        <AppInput
          label="Name"
          name="name"
          value={form.name}
          onChange={handleChange}
          placeholder="Enter your name"
        />
      )}

      <AppInput
        label="Email"
        name="email"
        value={form.email}
        onChange={handleChange}
        placeholder="Enter your email"
      />

      <AppInput
        label="Password"
        name="password"
        type="password"
        value={form.password}
        onChange={handleChange}
        placeholder="Enter your password"
      />

      <AppButton
        text={isLogin ? "Login" : "Create Account"}
        onClick={handleSubmit}
      />

      <p
        style={sharedStyles.link}
        onClick={() => setIsLogin(!isLogin)}
      >
        {isLogin ? "Create Account" : "Back to Login"}
      </p>
    </PageCard>
  );
}
